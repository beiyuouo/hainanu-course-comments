#include <iostream>
#include <string> 
using namespace std;
class Student
{
public:
    void display()
	 {
    	cout << "num: " << num << endl;
		cout << "name: " << name << endl;
		cout << "sex: " << sex << endl;
	}
private:
  	int num;
  	string name;
 	char sex;
};
