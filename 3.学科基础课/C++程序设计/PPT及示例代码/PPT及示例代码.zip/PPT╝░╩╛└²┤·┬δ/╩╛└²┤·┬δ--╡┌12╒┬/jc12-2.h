#include <iostream>
#include <string> 
using namespace std;
class UniversityStudent
{
public:
  	void display()
	 {
    	cout << "num: " << num << endl;
		cout << "name: " << name << endl;
		cout << "sex: " << sex << endl;
		cout << "major: " << major << endl;
		cout << "dormitory: " << dormitory << endl;
	 }
private:
  	int num;
  	string name;
  	char sex;
  	string major;
 	string dormitory;
};

