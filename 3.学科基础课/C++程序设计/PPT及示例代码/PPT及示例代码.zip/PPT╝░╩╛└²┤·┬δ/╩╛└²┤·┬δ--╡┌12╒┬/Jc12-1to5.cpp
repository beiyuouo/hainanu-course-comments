#include <iostream>
#include <string>
using namespace std;
class Student
{
public:
  void display() 
  {
    cout << "num: " << num << endl;
	cout << "name: " << name << endl;
	cout << "sex: " << sex << endl;
  }
private:
  int num;  
  string name;
  char sex;
};

class UniversityStudent:public Student 
{
public:
  void display_all()
   {
 //   cout << "num: " << num << endl; 
 //	cout << "name: " << name << endl; 	
 //   cout << "sex: " << sex << endl; 
 	display();
	cout << "major: " << major << endl;
	cout << "dormitory: " << dormitory << endl;
  }
private:
//  int num;
 // string name;
//  char sex;
  string major;
  string dormitory;
};

int main( )
{
  UniversityStudent uniStudent;
 // uniStudent.display() ; 
 
  uniStudent.display_all ( );
  return 0;
}

