#include <stdio.h>
int main() 
{
   char a=0;
   int num_space=0, num_e=0,num_i=0;
  for(   ;    ;scanf("%c",&a))
  {
     if(a==35)               //ASCII 35  ----  #
         break; 
      else if (a==32)          //ASCII 32  ----  space
         num_space++;
      else if (a==101)        //ASCII 101  ----  e
         num_e++;
      else if(a==105)         //ASCII 105  ----  i
	   num_i++;
   }
   printf("����Ŀո���ĸe����ĸi�ĸ����ֱ�Ϊ��%d�� %d��%d",num_space,num_e,num_i);
return 0;
}
