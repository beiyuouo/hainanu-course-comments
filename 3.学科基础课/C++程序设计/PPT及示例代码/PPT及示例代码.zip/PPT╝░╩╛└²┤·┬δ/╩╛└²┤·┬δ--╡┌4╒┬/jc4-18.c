#include <stdio.h>
int main()
{
    int i, sum=0;
    for(i=0;i<=100; )
   {
    sum = sum + i;
    i++;
	}
    printf("�������ǣ�%d",sum);
    return 0;
}

