    #include<stdio.h>
	int main()
	{	
		int a,b,c;
		printf("����������\n");
		scanf("%d,%d,%d",&a,&b,&c);
		printf("���ֵΪ��\n");
		if(a>b)
			if(a>c)
				printf("%d\n",a);
			else
				printf("%d\n",c);
		else
			if(b>c)
				printf("%d\n",b);
			else
				printf("%d\n",c);
		return 0;
	}

