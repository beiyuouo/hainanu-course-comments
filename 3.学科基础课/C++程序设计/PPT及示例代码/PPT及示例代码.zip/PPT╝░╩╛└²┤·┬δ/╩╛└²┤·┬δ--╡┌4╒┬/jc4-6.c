#include <stdio.h>
int main()
{
	int x,y;
	printf("������ٷ��Ƴɼ���");
	scanf("%d",&x);
	if(x>=90)
		y=4;
    else
   		{ 
        	if(x>=80)
               y=3;
        	else 
        	{
            	if(x>=70)
                	y=2;
        		else
              	{
                  if(x>=60)
                      y=1;
                  else
                      y=0;
     			}		
			}
     	}
     printf ("����Ƴɼ��ǣ�%d",y);
     return 0;
}
