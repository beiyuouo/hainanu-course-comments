#include <stdio.h>
int main()
{
    int i, sum=0;
    for(i=0;  ;i++)
    {
       sum = sum + i;
    }
    printf("�������ǣ�%d",sum);
    return 0;
}

