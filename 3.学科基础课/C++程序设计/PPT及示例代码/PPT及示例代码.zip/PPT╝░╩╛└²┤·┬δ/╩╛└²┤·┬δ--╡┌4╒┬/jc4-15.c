#include <stdio.h>
	int main()
	{
		int sum,i;
		for(sum=0,i=1;i<=100;sum=sum+i++)           ;
		printf("%d\n",sum);
		return 0;	
	}

