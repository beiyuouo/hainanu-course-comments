#include <stdio.h>
#include <math.h>
int main()
{
	int i=1;
	float pi=0.0;
	float a=1.0;
	while(fabs(a)>0.0001)
	{
		pi=pi+a;	
		a=pow(-1,i)*1.0/(2*i+1);
		i++;
	}
	printf("%f",4*pi);
 }
