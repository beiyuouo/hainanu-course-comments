#include <stdio.h>
int main()
{
    char a;
    scanf("%4c",&a);
    printf("%c",a);
    return 0;
}
