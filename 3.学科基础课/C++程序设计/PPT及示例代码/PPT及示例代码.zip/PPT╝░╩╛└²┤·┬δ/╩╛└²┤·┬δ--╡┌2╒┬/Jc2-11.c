#include <stdio.h>
int main()
{
  printf("%s\n","CHINA");
  printf("%3s\n","CHINA");
  printf("%7s\n","CHINA");
  printf("%3.2s\n","CHINA");
  printf("%3.6s\n","CHINA");
  printf("%7.2s\n","CHINA");
  printf("%-7s\n","CHINA");
  printf("%-5.3s\n","CHINA");
  return 0;
}
