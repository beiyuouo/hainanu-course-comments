#include <stdio.h>
int main()
{
    int a;
    scanf("%4d",&a);
    printf("%d",a);
    return 0;
}

