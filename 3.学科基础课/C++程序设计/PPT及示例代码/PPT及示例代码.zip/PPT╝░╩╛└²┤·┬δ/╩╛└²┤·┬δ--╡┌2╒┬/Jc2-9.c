#include <stdio.h>
int main()
{
   float a=123.456;
   double b=123456789.987654321;
   printf(" a=%f\n",a);  
   printf(" b=%f\n",b);  
   printf(" a=%10.2f\n",a);
   printf(" a=%-10.2f\n",a);
   return 0;
}

