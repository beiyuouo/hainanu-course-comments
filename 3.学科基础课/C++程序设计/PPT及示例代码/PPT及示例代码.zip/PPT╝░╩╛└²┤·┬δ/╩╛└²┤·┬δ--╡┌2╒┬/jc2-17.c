#include <stdio.h>
int main()
{
    char a[10];
    scanf("%5s",a);
    printf("%s",a);
return 0;
}
