#include <stdio.h>
int main()
{
    int a,b;
    scanf("%4d%d",&a,&b);
    printf("%d %d",a,b);
	return 0;
}

