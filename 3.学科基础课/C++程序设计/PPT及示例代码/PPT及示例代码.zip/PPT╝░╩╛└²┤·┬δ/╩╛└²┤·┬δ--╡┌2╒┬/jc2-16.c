#include <stdio.h>
int main()
{
    char a[10];
    scanf("%s",a);
    printf("%s",a);
    return 0;
}

