#include <stdio.h>
	int main()
	{
		printf("\"hello\"\n\t\\world\\\n"); 
		return 0;
	}

