#include<stdio.h>
int main()
{
    float x,y,z;
    x=1234567890;
    printf("%f\n",x); 
    y=12;
    z=x+y;
    printf("%f\n",z); 
    return 0;
}

