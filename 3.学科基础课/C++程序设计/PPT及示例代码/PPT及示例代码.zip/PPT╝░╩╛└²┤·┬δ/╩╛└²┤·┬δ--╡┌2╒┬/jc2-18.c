     #include <stdio.h>
	int main()
	{ 	
  		char a; int b;
  		a='h';
  		b=108;
  		putchar(a);
  		putchar('e');
  		putchar(b);
  		putchar(108);
  		putchar('q'-2);
  		putchar('\n');
        return 0;	
	}
