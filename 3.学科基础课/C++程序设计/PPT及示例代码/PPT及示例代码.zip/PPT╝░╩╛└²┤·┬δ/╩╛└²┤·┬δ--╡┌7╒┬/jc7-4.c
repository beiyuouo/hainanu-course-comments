#include <stdio.h>
int square(int *n)
{
  *n = *n * *n ; 
  return *n;
}


int main()
{
	int inumber=3,iresult,*p;
	p=&inumber;
	iresult=square(p);
	printf("3��ƽ��Ϊ��%d",*p);
    return 0;
}

