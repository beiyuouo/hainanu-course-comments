#include <stdio.h>
	int main()
	{
		char str[20]="hello",*p1=str,*p2="world";
		while(*p1++);
		*--p1=' ';
		while(*++p1=*p2++);
		printf("%s\n",str);
		return 0;	
	}

