#include <stdio.h>
int main() 
{
	char *string="I am happy";
	printf("%s\n",string);
	return 0;
}
