#include <stdio.h>
int square(int n)
{
   return n*n;
}
	int main()
	{
		int inumber=3,iresult=0;
		iresult=square(inumber);
		printf("%d��ƽ��Ϊ��%d",inumber,iresult);
        return 0;
    }

