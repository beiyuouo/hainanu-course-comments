#include <iostream>
using namespace std;
int main()
{
    int i, sum=0;
    for(i=0;i<=100;i++)
       sum = sum + i;
    cout<<"�������ǣ�"<<sum<<endl;
    return 0;
}

