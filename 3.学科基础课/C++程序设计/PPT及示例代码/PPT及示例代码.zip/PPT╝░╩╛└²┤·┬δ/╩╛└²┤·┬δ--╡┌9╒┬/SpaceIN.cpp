#include <iostream>
using namespace std;
int main ()
{
    char a[20];
    cin.get(a,20);
    cout<<a;
    return 0;
}

