#include <iostream>           
using namespace std;
float average(float a,float b) 
{
    float c;      
    c=(a+b)/2;   
    return c;     
}
int main()  
{
    float x,y,z;  
    cout<<"��������������:";
    cin>>x>>y;
    z=average(x,y);   
    cout<<"average:"<<z;
    return 0;
}

