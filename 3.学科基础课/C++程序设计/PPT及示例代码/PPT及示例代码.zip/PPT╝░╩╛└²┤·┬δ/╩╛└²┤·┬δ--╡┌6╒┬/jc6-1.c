	int sum(int x, int y)
	{
		int z;
		z=x+y;
		return z;
	}

