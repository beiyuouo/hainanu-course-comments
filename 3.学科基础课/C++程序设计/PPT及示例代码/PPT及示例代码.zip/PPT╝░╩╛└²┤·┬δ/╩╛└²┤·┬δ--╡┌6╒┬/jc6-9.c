#include<stdio.h>
int main()
{
	void sub(int b[][3]);	
	int a[3][3]={{1,2,3},{4,5,6},{7,8,9}};
	int i,j;
	printf("�û�ǰ��\n");
	for(i=0;i<3;i++)
	{	
		for(j=0;j<3;j++)
			printf("%d  ",a[i][j]);
		printf("\n");
	}
	sub(a);
	printf("�û���\n");
	for(i=0;i<3;i++)
	{	
		for(j=0;j<3;j++)
			printf("%d  ",a[i][j]);
		printf("\n");
	}
	return 0;
	}
void sub(int b[][3])
{
	int i,j,t;
	for(i=0; i<3; i++)
		for(j=0; j<i; j++)
		{
			t=b[i][j];
			b[i][j]=b[j][i];
			b[j][i]=t;
		}		
}	

