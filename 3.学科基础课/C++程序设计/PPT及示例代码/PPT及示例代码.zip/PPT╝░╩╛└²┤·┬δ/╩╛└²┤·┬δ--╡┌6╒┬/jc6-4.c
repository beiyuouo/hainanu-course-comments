#include<stdio.h>
int main()							
{ 
	float a,b,m;
	float avg(float, float);
	printf("����ɼ���\n");
	scanf("%f%f",&a,&b);
	m=avg(a,b);
	printf("ƽ����Ϊ��\n%.1f\n",m);
	return 0;
} 
float avg(float x, float y)
{
	float sum(float, float) ;
	return sum(x,y)/2;
}
float sum(float x, float y)
{
	return (x+y);
}

