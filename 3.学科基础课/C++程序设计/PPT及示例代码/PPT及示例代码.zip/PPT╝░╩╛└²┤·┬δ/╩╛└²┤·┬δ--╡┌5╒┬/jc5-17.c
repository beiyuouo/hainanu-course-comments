#include <stdio.h>
#include <string.h>
int main()
{
	char a[]="HeLlO wORlD";
	strupr(a);
	printf("%s\n",a);
	printf("%s\n",strlwr(a));	
	return 0;
}	

