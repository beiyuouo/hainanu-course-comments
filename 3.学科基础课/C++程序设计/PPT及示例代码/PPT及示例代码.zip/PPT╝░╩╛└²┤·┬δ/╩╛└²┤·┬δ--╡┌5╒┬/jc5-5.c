#include<stdio.h>
	int main()							
	{ 
		int i,j,min,mini,minj;
		int a[3][4]={{12,21,34,32},{28,10,17,43},{19,54,38,27}};
		min=a[0][0];	mini=0;	minj=0;
		for(i=0;i<3;i++)
		{
			for(j=0;j<4;j++)
			{
				printf("a[%d][%d]=%d  ",i,j,a[i][j]);
				if(a[i][j]<min)
				{	
					min=a[i][j];
					mini=i;
					minj=j;
				}
			}
			printf("\n");
		}
		printf("min is a[%d][%d]=%d\n",mini,minj,min);
		return 0;
}
