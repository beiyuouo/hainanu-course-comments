#include<stdio.h>
int main()
{	
	char a[15];
	int i;
	for(i=0;i<15;i++) 
	{
		scanf("%c\n",&a[i]);
		printf("%c",a[i]);
	}
	printf("\n");
	return 0;
}	

