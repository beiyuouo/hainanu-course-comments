#include<stdio.h>
	int main()							
	{
		char a[10],b[10],c[10];
		scanf("%s%s%s",a,b,c);
		printf("%s %s %s\n",a,b,c); 
		return 0;
	}	

