#include <stdio.h>
#include <string.h>
int main()
{
	char a[20]="hello",b[ ]="hi";
	printf("%s\n",a);
	strcpy(a,b);
	printf("%s\n",a);
	strcpy(a,"see you again\n");
	printf("%s",a) ;
	return 0;
}
