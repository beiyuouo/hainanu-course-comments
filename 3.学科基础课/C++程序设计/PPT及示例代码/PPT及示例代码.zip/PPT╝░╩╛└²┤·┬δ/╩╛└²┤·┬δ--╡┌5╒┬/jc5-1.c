#include<stdio.h>
int main()							
{ 
 	int a[5],i;
	for(i=0;i<5;i++)
	{
		a[i]=i+1;
		printf("a[%d]=%d  ",i,a[i]);
	}
	printf("\n");
	return 0;
}

