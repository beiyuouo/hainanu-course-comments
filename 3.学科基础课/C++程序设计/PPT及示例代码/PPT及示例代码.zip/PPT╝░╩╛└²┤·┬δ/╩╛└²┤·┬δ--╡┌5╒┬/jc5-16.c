    #include <stdio.h>
	#include <string.h>
	int main()
	{
		char a[]="good";
		printf("%d,%d\n",strlen(a),strlen("bye"));
		return 0;
	}
