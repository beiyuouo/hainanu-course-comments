#include<stdio.h>
	int main()							
	{
		int i;
		char a[15];
		gets(a);
		puts(a);
		gets(a);
		puts(a);
		return 0;	
	}

