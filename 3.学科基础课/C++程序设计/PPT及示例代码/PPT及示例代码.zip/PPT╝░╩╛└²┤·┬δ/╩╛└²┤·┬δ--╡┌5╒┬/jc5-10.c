#include<stdio.h>
int main()						
{
	char c[12];
	scanf("%s",c);
//	c[12]='\0';
	printf("%s\n",c);
	return 0;
}	

