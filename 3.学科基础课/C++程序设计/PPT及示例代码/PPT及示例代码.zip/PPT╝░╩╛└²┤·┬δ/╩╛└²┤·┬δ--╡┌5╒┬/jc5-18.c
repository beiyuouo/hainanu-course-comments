         #include<stdio.h>
	int main()
	{
		int a[][3]={1,2,3,4,5,6,7,8,9};
		int i,j,s=0;
		for(i=0;i<3;i++)
		{	
			for(j=0;j<3;j++)
				printf("%d   ",a[i][j]);
			printf("\n");
		}	
		for(i=0;i<3;i++)
			for(j=0;j<3;j++)
				if(i==j) s=s+a[i][j];
		printf("�Խ���Ԫ��֮�ͣ�%d\n",s);
		return 0;
	}

