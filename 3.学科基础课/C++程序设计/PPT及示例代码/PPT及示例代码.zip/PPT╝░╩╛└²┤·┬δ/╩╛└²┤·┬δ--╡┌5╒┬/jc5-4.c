#include<stdio.h>
	int main()							
	{ 
		int a[3][3],i,j,m=1;
		for(i=0;i<3;i++) 
		{
			for(j=0;j<3;j++)
			{
				a[i][j]=m++;
				printf("%d  ",a[i][j]);
			}
			printf("\n");
		}
		return 0;
	}

