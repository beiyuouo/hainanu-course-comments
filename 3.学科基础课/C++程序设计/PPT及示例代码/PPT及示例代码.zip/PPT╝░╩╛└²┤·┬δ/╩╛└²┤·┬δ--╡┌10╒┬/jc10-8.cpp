#include <iostream>
#include <string>
using namespace std;
int main()
{
    string s1="ABC",s2="def",s3;  	//s1:ABC ,s2:def,s3Ϊ���ַ���
    s3=s1.append(s2);           	//s1:ABCdef , s3:ABCdef
    cout<<s3<<endl;
    int s1cmps2=s1.compare(s2);  	//s1cmps2ֵΪ-1,��ʾs1<s2
    cout<<s1cmps2<<endl;
    s1.insert(0,s2);             	//s1:defABCdef
    cout<<s1<<endl;
    s3=s1.substr(2,3);          	//s3:fAB
    cout<<s3<<endl;
    cout<<s1.length()<<endl;         		//s1:defABCdef,����Ϊ9
    string str="de";
    int pos=s1.find(str); 
	cout<<pos<<endl; 	
//��"defABCdef"�в���"de"�Ӵ���һ�γ��ֵ�λ��
}

