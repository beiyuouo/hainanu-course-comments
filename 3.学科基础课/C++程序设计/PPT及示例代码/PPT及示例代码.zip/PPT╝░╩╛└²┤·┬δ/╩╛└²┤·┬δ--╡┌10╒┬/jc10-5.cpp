#include <iostream>
#include <string>
using namespace std;
int main()
{
    char *s="Hello World!";
	string s1=string();    
	string s2=string(s);  	 
    string s3= string(s2);   
    string s4=string(s, 6, 5);
    string s5=string(s, 5);
    string s6=string(4, 'a');
    string s7="c++ programming";  
    cout<<"s1: "<<s1<<endl
	    <<"s2: "<<s2<<endl
		<<"s3: "<<s3<<endl
		<<"s4: "<<s4<<endl
		<<"s5: "<<s5<<endl
		<<"s6: "<<s6<<endl
		<<"s7: "<<s7;
    return 0;
}

