#include <iostream>
#include <string>
using namespace std;
int main()
 {
    string first, second;
    getline(cin, first, ',');
    getline(cin, second);
    cout <<"First:" <<first<<endl<<"Second:" << second << endl;
	return 0;
}

