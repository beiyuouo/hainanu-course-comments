#include <stdio.h>      
int main()
{
	int a,b;
	printf("a=%d,b=%d, e=%d\n",a,b,b=(a=1,2*3));
	printf("a=%d,b=%d, e=%d\n",a,b,(b=a=1,2*3));
    printf("a=%d,b=%d, e=%d\n",a,b,b=a=1,2*3);
	return 0;
}

