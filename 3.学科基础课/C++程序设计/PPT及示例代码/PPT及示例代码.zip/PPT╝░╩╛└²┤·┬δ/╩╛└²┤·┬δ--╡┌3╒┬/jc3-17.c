#include<stdio.h>
int main()
{
		char a='a';
		short b=-5;
		int c=100;	
		unsigned int u=100;	
		float f=0.234, x;
   		x=c+a+1.5*u+f/'b'-b*3.1415926;
   		printf("x=%lf",x);
		return 0;
	}

