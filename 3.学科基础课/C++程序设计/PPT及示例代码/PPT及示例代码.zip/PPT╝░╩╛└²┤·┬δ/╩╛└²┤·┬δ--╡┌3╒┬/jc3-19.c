#include<stdio.h>
	int main()
	{	
		int a=5,b=2;
		double c,d,e,f;
		c=(double)a/b;
		d=a/b;
		e=(int)1.8+2.5;
		f=(int)( 1.8+2.5);
		printf("c=%.1lf,d=%.1lf\n",c,d);
		printf("e=%.1lf,f=%.1lf\n",e,f);
		return 0;
	}

