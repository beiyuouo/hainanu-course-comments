#include <stdio.h>
int main()
{
      int a=3 , b=3;
   	  int c=1; 
	  printf("a=%d��++a=%d\n", a, ++a); 

	  printf("b=%d��b++=%d\n",b, b++); 
	  
	
	  printf("%d, %d, %d\n",  c,++c,c++);
	  c=1;
	  printf("%d, %d, %d\n", ++c, c,c++); 
	  c=1;
	  printf("%d, %d, %d\n", ++c,c++, c); 
	  c=1;
	  printf("%d, %d, %d\n",c++,++c, c); 
	  return 0;
}

