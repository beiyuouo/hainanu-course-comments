#include <stdio.h>
int main()
{
	printf("%f\n",'A');
	printf("%f\n",(double)'A');
	printf("%d\n",(int)1.5+ 'A' );
	printf("%d\n",(int)(1.5+ 'A' ));
    return 0;
}
