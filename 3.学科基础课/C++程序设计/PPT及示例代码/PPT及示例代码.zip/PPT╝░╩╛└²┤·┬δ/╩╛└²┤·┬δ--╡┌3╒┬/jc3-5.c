#include <stdio.h>
int main()
{
      int a=3,b=3;	
      a++;
      printf("%d\n",a); 
      ++b;
      printf("%d\n",b);
      return 0;
}

