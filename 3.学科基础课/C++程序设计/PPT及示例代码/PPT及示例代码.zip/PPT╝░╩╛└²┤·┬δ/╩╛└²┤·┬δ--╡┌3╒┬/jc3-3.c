#include <stdio.h>      
int main()
{
	short a,b,c=10;
		a=3.7;			
		b=65537;
		c%=a+b;
	printf("a=%d,b=%d,c=%d\n",a,b,c);
	return 0;
}

