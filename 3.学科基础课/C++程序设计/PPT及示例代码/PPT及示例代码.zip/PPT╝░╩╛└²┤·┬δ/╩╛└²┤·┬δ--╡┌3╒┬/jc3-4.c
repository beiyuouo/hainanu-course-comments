#include <stdio.h>      
int main()
{
	int a=256;
	char c;
	c=a;
	printf("%c",c);
	return 0;
}

