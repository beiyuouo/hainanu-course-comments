#include <stdio.h>
int main()
{
      int a=3,b=0;
	  a==3;
	  printf("a=%d\n",a); 
	  b=3;
	  printf("b=%d\n",b); 
	  return 0;
}

