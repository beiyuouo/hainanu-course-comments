#include <stdio.h>
int main()
{
	int a=-5,b=3,c;
	c=(a/b)*b;
    printf("%d\n",c);
	c=a%b;
	printf("%d\n",c);
	c=a/b*b+a%b;
	printf("%d\n",c);
	return 0;
}
