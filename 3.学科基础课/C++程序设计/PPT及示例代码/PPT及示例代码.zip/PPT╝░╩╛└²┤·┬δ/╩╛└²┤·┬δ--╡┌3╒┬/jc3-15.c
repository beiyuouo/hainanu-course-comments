#include <stdio.h>      
int main()
{
	int a=3,b;
	int x=3,y;
	b=!5>2||(a=0)&&(a+=1);
	
	y=!5<2||(x=0)&&(x+=1);
	
	printf("a=%d,b=%d\n",a,b);
	printf("x=%d,y=%d\n",x,y);
	return 0;
}

