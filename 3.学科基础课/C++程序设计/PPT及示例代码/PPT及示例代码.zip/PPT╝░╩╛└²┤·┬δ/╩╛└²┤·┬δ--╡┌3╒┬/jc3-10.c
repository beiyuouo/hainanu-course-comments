#include <stdio.h>
int main()
{
    char c='k';
    int i=1, j=2, k=3;
    float y=0.85;
    printf( "%d\n", 'a'+5<c);             //  ��
	printf( "%d\n", -i-2*j>=k+1 );        //  ��
    printf( "%d\n", 1<j<5);               //  ��
	printf( "%d\n", y==0.85 );            //  ��
	printf( "%d\n", k==j==i+5 );          //  ��
    return 0;
}

