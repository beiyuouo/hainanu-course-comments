#include <stdio.h>
int main()
{
      int a=3,b=1;
	  printf("%d\n",a==3); 
	  printf("%d\n",b==3); 
	  return 0;
}

