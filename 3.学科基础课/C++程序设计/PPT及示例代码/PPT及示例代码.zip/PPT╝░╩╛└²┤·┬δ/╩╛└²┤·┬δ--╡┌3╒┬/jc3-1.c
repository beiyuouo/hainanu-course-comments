#include <stdio.h>      
int main()
{
	int a=1,b;
	b=a+'A'%10/2-3*4;
	printf("%d",b);
	return 0;
}

