#include <stdio.h>      
int main()
{
	int a=0,b=1,c;
	c=a&&(b=2);	
	printf("a=%d,b=%d,c=%d\n",a,b,c);
	return 0;
}

