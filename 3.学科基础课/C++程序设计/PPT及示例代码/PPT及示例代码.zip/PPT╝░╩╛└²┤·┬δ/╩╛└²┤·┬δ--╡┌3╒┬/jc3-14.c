#include<stdio.h>
int main()
{
    int x,y,z;
    x=1,   y=0,   z=2;
    ++z && ++x || y++;
	printf("%d,%d,%d\n",x,y,z); 
	return 0;
}

