//�ļ�2��Circle���ʵ��
//#include "Circle.h"
#include "Circle.h"
#include <iostream>
using namespace std;
int Circle::Count=0;                   
Circle::Circle(double r=1) 
{         
	radius=r;
	Count++;
}

Circle::Circle(Circle &p) 
{	               
	radius=p.radius;
	Count++;
}

Circle::~Circle() { Count--; }     
double Circle::getRadius(){return radius;}

void Circle::showCount() 
{		            
	cout << "  Object count = " << Count << endl;
}

