#include <iostream>
#include "MulCom.h"
#include "MulCom.cpp"
using namespace std;
int main()
{
	MulCom mc(15);
	cout<<mc.getr() ;
	return 0;
}
