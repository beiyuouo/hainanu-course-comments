#include <iostream>
#include "MulCom.h"
MulCom::MulCom(int i)
{
	r=i;
}

MulCom::MulCom(MulCom &p)
{
	r=p.r;
}

int MulCom::getr()
{
	return r;
 } 

