#ifndef MulCom_h
#define MulCom_h
class MulCom
{
	public:
		MulCom(int i=1);
		MulCom(MulCom &p);
		int getr();
	private:
		int r;
};

#endif 
