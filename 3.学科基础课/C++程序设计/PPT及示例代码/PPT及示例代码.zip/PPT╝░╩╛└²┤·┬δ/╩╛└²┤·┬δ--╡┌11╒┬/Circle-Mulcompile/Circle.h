
//�ļ�1����Ķ��壬Circle.h
#include <iostream>
#ifndef Circle_h
	#define Circle_h
	class Circle
	 {	                        // Circle�ඨ��
	public:	                             
		Circle(double r=1) ;
		Circle(Circle &p) ;
		~Circle() ;    
	    double getRadius();
	    static void showCount() ;
	private:	                            
		double radius;
		static int Count;	 
	};
#endif

