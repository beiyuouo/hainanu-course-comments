//�ļ�3����������main.cpp
#include "Circle.h"
#include "Circle.cpp" 
int main() 
{	               	//������
	Circle a(5);	            
	cout << "Radius of CCircle a: " << a.getRadius() << endl;
	Circle::showCount();	       
	Circle  b(a);	           
	cout << "Radius of CCircle b: " << b.getRadius() << endl;
	Circle::showCount();	       
	return 0;
}

