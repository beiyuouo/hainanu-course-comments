//�ļ�2��CCircle���ʵ��
#include "Circle.h"
using namespace std;
int Circle::Count=0;                   
Circle::Circle(double r) 
{         
	radius=r;
	Count++;
}

Circle::Circle(Circle &p) 
{	               
	radius=p.radius;
	Count++;
}

Circle::~Circle() { Count--; }     
double Circle::getRadius(){return radius;}

void Circle::showCount() 
{		            
	cout << "  Object count = " << Count << endl;
}

